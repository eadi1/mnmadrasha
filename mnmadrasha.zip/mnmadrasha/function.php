<?php
// Activation hook to create tables and add teacher role
function school_management_plugin_activate() {
    global $wpdb;
  
    $charset_collate = $wpdb->get_charset_collate();

    // Define database tables with $wpdb->prefix
    $tables = [
        'subject_by_class' => "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}subject_by_class (
            id INT AUTO_INCREMENT PRIMARY KEY,
            class_name INT(11) NULL,
            subject_name INT(11) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;",

        'teachers' => "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}teachers (
            id INT(11) NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            father_name VARCHAR(255) NOT NULL,
            phone_number VARCHAR(15) NOT NULL,
            email VARCHAR(255) NOT NULL,
            permanent_address TEXT NOT NULL,
            teacher_picture VARCHAR(255) DEFAULT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",

        'subjects' => "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}subjects (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            en VARCHAR(100) NOT NULL,
            bn VARCHAR(100) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",

        'classes' => "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}classes (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            en VARCHAR(100) NOT NULL,
            bn VARCHAR(100) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",
    ];

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    foreach ($tables as $table_sql) {
        dbDelta($table_sql);
    }
}

// Deactivation hook to drop tables
function school_management_plugin_deactivate() {
    global $wpdb;
    $tables = ['subject_by_class', 'teachers', 'subjects', 'classes'];

    foreach ($tables as $table) {
        
        $wpdb->query($wpdb->prepare("DROP TABLE IF EXISTS %s", $wpdb->prefix.$table));

    }
}

// Add Teacher role with specific capabilities

// Main Admin Dashboard page
function school_management_dashboard() {
    include(plugin_dir_path(__FILE__) . 'templates/dashboard.php');
}

// Dashboard Menu and Submenus
function school_management_add_admin_menu() {
    add_menu_page('School Management', 'School Management', 'manage_options', 'school_management', 'school_management_dashboard');

    add_submenu_page('school_management', 'Class Wise Subjects', 'Class Wise Subjects', 'manage_options', 'school_management_subjects_by_class', 'school_management_subjects_by_class');
    add_submenu_page('school_management', 'Teachers', 'Teachers', 'manage_options', 'school_management_teachers', 'school_management_teachers_page');
    add_submenu_page('school_management', 'Subjects', 'Subjects', 'manage_options', 'school_management_subjects', 'school_management_subjects_page');
    add_submenu_page('school_management', 'Classes', 'Classes', 'manage_options', 'school_management_classes', 'school_management_classes_page');
}
add_action('admin_menu', 'school_management_add_admin_menu');

// Include specific pages for each submenu
function school_management_subjects_by_class() {
    include(plugin_dir_path(__FILE__) . 'templates/class_wise_subject.php');
}

function school_management_teachers_page() {
    include(plugin_dir_path(__FILE__) . 'templates/teacher-management.php');
}

function school_management_subjects_page() {
    include(plugin_dir_path(__FILE__) . 'templates/subject-management.php');
}

function school_management_classes_page() {
    include(plugin_dir_path(__FILE__) . 'templates/class-management.php');
}



function refresh() {
    echo "<script>window.location.reload();</script>";
}

// Shortcode to display a contact form
function mnmadrasha_contact_form_shortcode() {
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mnmadrasha_contact_form'])) {
        $name    = sanitize_text_field($_POST['name']);
        $email   = sanitize_email($_POST['email']);
        $message = sanitize_textarea_field($_POST['message']);
        
        // Send email to site admin
        $to      = get_option('admin_email');
        $subject = "Contact Form Message from $name";
        $headers = array('Content-Type: text/html; charset=UTF-8', "From: $name <$email>");
        $body    = "Name: $name<br>Email: $email<br><br>Message:<br>$message";

        wp_mail($to, $subject, $body, $headers);
        
        // Display a thank you message
        echo '<p>Thank you for your message! We will get back to you soon.</p>';
    }
    
    // Display the contact form
    ob_start();
    ?>
    <form action="" method="post" class="mnmadrasha-contact-form">
        <p>
            <label for="name">Name:</label>
            <input type="text" name="name" required>
        </p>
        <p>
            <label for="email">Email:</label>
            <input type="email" name="email" required>
        </p>
        <p>
            <label for="message">Message:</label>
            <textarea name="message" rows="5" required></textarea>
        </p>
        <p>
            <input type="submit" value="Send">
            <input type="hidden" name="mnmadrasha_contact_form" value="1">
        </p>
    </form>
    <?php
    return ob_get_clean();
}

// Register the contact form shortcode
add_shortcode('mnmadrasha_contact_form', 'mnmadrasha_contact_form_shortcode');
?>
