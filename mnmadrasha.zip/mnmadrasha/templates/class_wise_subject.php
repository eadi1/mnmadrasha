<?php
global $wpdb;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_class_subject'])) {
    // Check nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'class_subject_form')) {
        die('Security check failed.');
    }

    // Sanitize and capture form data
    $class_name = isset($_POST['class_name']) ? sanitize_text_field(wp_unslash($_POST['class_name'])) : '';
    $subject_name = isset($_POST['subject_name']) ? sanitize_text_field(wp_unslash($_POST['subject_name'])) : '';

    // Insert into selected_class_subjects table if data is valid
    if ($class_name && $subject_name) {
        $wpdb->insert("{$wpdb->prefix}subject_by_class", [
            'class_name' => $class_name,
            'subject_name' => $subject_name,
        ]);

        echo '<div class="updated-message">Class and subject saved successfully!</div>';
        echo '<script>refresh();</script>';
    }
}

$selected_class = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}classes");
$selected_subjects = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}subjects");
?>
<script>
// JavaScript function to refresh the page
function refresh() {
    window.location.href = "<?php echo esc_url(admin_url('admin.php?page=school_management_classes_subjects')); ?>";
}
</script>

<form method="post" class="subject-form">
    <?php wp_nonce_field('class_subject_form'); ?>
    <div class="form-group">
        <label for="en">Class Name:</label>
        <select name="class_name" id="en" required>
            <option value="0">Select Class</option>
            <?php
            foreach ($selected_class as $class) {
                echo '<option value="' . esc_attr($class->id) . '">' . esc_html($class->bn) . '</option>';
            }
            ?>
        </select>
    </div>
    <div class="form-group">
        <label for="bn">Subject:</label>
        <select name="subject_name" id="bn" required>
            <option value="0">Select Subject</option>
            <?php
            foreach ($selected_subjects as $subject) {
                echo '<option value="' . esc_attr($subject->id) . '">' . esc_html($subject->bn) . '</option>';
            }
            ?>
        </select>
    </div>
    <div class="form-group">
        <input type="submit" name="submit_class_subject" value="Add Subject" class="button-primary">
    </div>
</form>

<?php
// Get all classes and subjects grouped by class
$results = $wpdb->get_results("
    SELECT c.bn AS class_name, s.bn AS subject_name
    FROM {$wpdb->prefix}subject_by_class AS sc
    JOIN {$wpdb->prefix}classes AS c ON sc.class_name = c.id   
    JOIN {$wpdb->prefix}subjects AS s ON sc.subject_name = s.id
    ORDER BY c.bn
");

// Group subjects by class
$classes = [];
foreach ($results as $row) {
    $classes[$row->class_name][] = $row->subject_name;
}

if (!empty($classes)) {
    echo "<table class='wp-list-table widefat fixed striped'>";
    echo "<thead><tr><th>Class Name</th><th>Subjects</th></tr></thead>";
    echo "<tbody>";
    
    foreach ($classes as $class_name => $subjects) {
        echo "<tr><td colspan='2'><h5>" . esc_html($class_name) . "</h5></td></tr>";
        
        foreach ($subjects as $subject) {
            echo "<tr>";
            echo "<td></td>";
            echo "<td>" . esc_html($subject) . "</td>";
            echo "</tr>";
        }
    }

    echo "</tbody></table>";
} else {
    echo "<p>No subjects found for any class.</p>";
}
?>
<style>
/* Basic styling for the page */
.page-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

/* Style for the form */
.subject-form {
    margin-bottom: 30px;
    padding: 20px;
    background-color: #f4f4f4;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group select {
    width: 100%;
    padding: 8px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.form-group input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 4px;
}

.form-group input[type="submit"]:hover {
    background-color: #45a049;
}

/* Styling for the message after successful action */
.updated-message {
    background-color: #d4edda;
    color: #155724;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
}

/* Styling for the table */
.subjects-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.subjects-table th, .subjects-table td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
}

.subjects-table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

.subjects-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.subjects-table a {
    text-decoration: none;
    padding: 5px 10px;
    margin: 0 5px;
    border-radius: 4px;
}

.button-edit {
    background-color: #ffa500;
    color: white;
}

.button-edit:hover {
    background-color: #e68900;
}

.button-delete {
    background-color: #ff4d4d;
    color: white;
}

.button-delete:hover {
    background-color: #e60000;
}
</style>
