<?php
global $wpdb;
$table_name = $wpdb->prefix . 'subjects';

// Fetch the subject to edit
$subject_to_edit = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $subject_to_edit = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $edit_id));
}

// JavaScript refresh function


// Handle form submission to update the subject
if (isset($_POST['update_subject'])) {
    $subject_name = sanitize_text_field($_POST['en']);
    $section = sanitize_text_field($_POST['bn']);
    $subject_id = intval($_POST['subject_id']);
    
    $wpdb->update(
        $table_name,
        ['en' => $subject_name, 'bn' => $section],
        ['id' => $subject_id],
        ['%s', '%s'],
        ['%d']
    );

    echo '<div class="updated-message">Subject updated successfully!</div>';
    refresh();
}

// Handle form submission to add a new subject
if (isset($_POST['add_subject'])) {
    $subject_name = sanitize_text_field($_POST['en']);
    $section = sanitize_text_field($_POST['bn']);
    
    $wpdb->insert(
        $table_name,
        ['en' => $subject_name, 'bn' => $section],
        ['%s', '%s']
    );

    echo '<div class="updated-message">New subject added successfully!</div>';
    refresh();
}

// Handle deletion of a subject
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $wpdb->delete($table_name, ['id' => $delete_id], ['%d']);
  
    echo '<div class="updated-message">Subject deleted successfully!</div>';
    refresh();
}

// Fetch all subjects for display
$subjects = $wpdb->get_results("SELECT * FROM $table_name"); 
?>

<h2 class="page-title">Manage Subjects</h2>

<!-- Form to Add or Edit Subject -->
<?php if ($subject_to_edit): ?>
    <!-- Edit Subject Form -->
    <form method="post" class="subject-form">
        <input type="hidden" name="subject_id" value="<?php echo esc_attr($subject_to_edit->id); ?>">
        <div class="form-group">
            <label for="en">Subject Name:</label>
            <input type="text" name="en" id="en" value="<?php echo esc_attr($subject_to_edit->en); ?>" required>
        </div>
        <div class="form-group">
            <label for="bn">Subject Name in Bangla:</label>
            <input type="text" name="bn" id="bn" value="<?php echo esc_attr($subject_to_edit->bn); ?>" required>
        </div>
        <div class="form-group">
            <input type="submit" name="update_subject" value="Update Subject" class="button-primary">
        </div>
    </form>
<?php else: ?>
    <!-- Add New Subject Form -->
    <form method="post" class="subject-form">
        <div class="form-group">
            <label for="en">Subject Name:</label>
            <input type="text" name="en" id="en" required>
        </div>
        <div class="form-group">
            <label for="bn">Subject Name in Bangla:</label>
            <input type="text" name="bn" id="bn" required>
        </div>
        <div class="form-group">
            <input type="submit" name="add_subject" value="Add Subject" class="button-primary">
        </div>
    </form>
<?php endif; ?>

<!-- Table to Display All Subjects -->
<table class="subjects-table">
    <thead>
        <tr>
            <th>Subject Name</th>
            <th>Name in Bangla</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($subjects as $subject): ?>
            <tr>
                <td><?php echo esc_html($subject->en); ?></td>
                <td><?php echo esc_html($subject->bn); ?></td>
                <td>
                    <!-- Edit and Delete Links -->
                    <a href="?page=school_management_subjects&edit_id=<?php echo esc_attr($subject->id); ?>" class="button-edit">Edit</a>
                    <a href="?page=school_management_subjects&delete_id=<?php echo esc_attr($subject->id); ?>" onclick="return confirm('Are you sure you want to delete this subject?');" class="button-delete">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<style>
/* Basic styling for the page */
.page-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

/* Style for the form */
.subject-form {
    margin-bottom: 30px;
    padding: 20px;
    background-color: #f4f4f4;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group input[type="text"] {
    width: 100%;
    padding: 8px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.form-group input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 4px;
}

.form-group input[type="submit"]:hover {
    background-color: #45a049;
}

/* Styling for the message after successful action */
.updated-message {
    background-color: #d4edda;
    color: #155724;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
}

/* Styling for the table */
.subjects-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.subjects-table th, .subjects-table td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
}

.subjects-table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

.subjects-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.subjects-table a {
    text-decoration: none;
    padding: 5px 10px;
    margin: 0 5px;
    border-radius: 4px;
}

.button-edit {
    background-color: #ffa500;
    color: white;
}

.button-edit:hover {
    background-color: #e68900;
}

.button-delete {
    background-color: #ff4d4d;
    color: white;
}

.button-delete:hover {
    background-color: #e60000;
}
</style>
