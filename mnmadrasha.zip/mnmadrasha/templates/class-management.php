<?php
global $wpdb;
$table_name = $wpdb->prefix . 'classes';

// Fetch the class to edit
$class_to_edit = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $class_to_edit = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $edit_id));
}

// Handle form submission to update the class
if (isset($_POST['update_class'])) {
    $class_name = sanitize_text_field($_POST['en']);
    $section = sanitize_text_field($_POST['bn']);
    $class_id = intval($_POST['class_id']);
    
    $wpdb->update($table_name, [
        'en' => $class_name,
        'bn' => $section
    ], ['id' => $class_id]);

    echo '<div class="updated-message">Class updated successfully!</div>';
    echo '<script>refresh();</script>';
}

// Handle form submission to add a new class
if (isset($_POST['add_class'])) {
    $class_name = sanitize_text_field($_POST['en']);
    $section = sanitize_text_field($_POST['bn']);
    
    $wpdb->insert($table_name, [
        'en' => $class_name,
        'bn' => $section
    ]);

    echo '<div class="updated-message">New class added successfully!</div>';
    echo '<script>refresh();</script>';
}

// Handle deletion of a class
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $wpdb->delete($table_name, ['id' => $delete_id]);
  
    echo '<div class="updated-message">Class deleted successfully!</div>';
    echo '<script>refresh();</script>';
}

// Fetch all classes for display
$classes = $wpdb->get_results("SELECT * FROM $table_name"); 
?>

<script>
// JavaScript function to refresh the page
function refresh() {
    window.location.href = "<?php echo esc_url(admin_url('admin.php?page=school_management_classes')); ?>";
}
</script>

<h2 class="page-title">Manage Classes</h2>

<!-- Form to Add or Edit Class -->
<?php if (isset($class_to_edit)): ?>
    <!-- Edit Class Form -->
    <form method="post" class="class-form">
        <input type="hidden" name="class_id" value="<?php echo esc_attr($class_to_edit->id); ?>">
        <div class="form-group">
            <label for="en">Class Name:</label>
            <input type="text" name="en" id="en" value="<?php echo esc_attr($class_to_edit->en); ?>" required>
        </div>
        <div class="form-group">
            <label for="bn">Class Name in Bangla:</label>
            <input type="text" name="bn" id="bn" value="<?php echo esc_attr($class_to_edit->bn); ?>" required>
        </div>
        <div class="form-group">
            <input type="submit" name="update_class" value="Update Class" class="button-primary">
        </div>
    </form>
<?php else: ?>
    <!-- Add New Class Form -->
    <form method="post" class="class-form">
        <div class="form-group">
            <label for="en">Class Name:</label>
            <input type="text" name="en" id="en" required>
        </div>
        <div class="form-group">
            <label for="bn">Class Name in Bangla:</label>
            <input type="text" name="bn" id="bn" required>
        </div>
        <div class="form-group">
            <input type="submit" name="add_class" value="Add Class" class="button-primary">
        </div>
    </form>
<?php endif; ?>

<!-- Table to Display All Classes -->
<table class="classes-table">
    <thead>
        <tr>
            <th>Class Name</th>
            <th>Name in Bangla</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($classes as $class): ?>
            <tr>
                <td><?php echo esc_html($class->en); ?></td>
                <td><?php echo esc_html($class->bn); ?></td>
                <td>
                    <!-- Edit and Delete Links -->
                    <a href="?page=school_management_classes&edit_id=<?php echo esc_attr($class->id); ?>" class="button-edit">Edit</a>
                    <a href="?page=school_management_classes&delete_id=<?php echo esc_attr($class->id); ?>" onclick="return confirm('Are you sure you want to delete this class?');" class="button-delete">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<style>
/* Basic styling for the page */
.page-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

/* Style for the form */
.class-form {
    margin-bottom: 30px;
    padding: 20px;
    background-color: #f4f4f4;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group input[type="text"] {
    width: 100%;
    padding: 8px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.form-group input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 4px;
}

.form-group input[type="submit"]:hover {
    background-color: #45a049;
}

/* Styling for the message after successful action */
.updated-message {
    background-color: #d4edda;
    color: #155724;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
}

/* Styling for the table */
.classes-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.classes-table th, .classes-table td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
}

.classes-table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

.classes-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.classes-table a {
    text-decoration: none;
    padding: 5px 10px;
    margin: 0 5px;
    border-radius: 4px;
}

.button-edit {
    background-color: #ffa500;
    color: white;
}

.button-edit:hover {
    background-color: #e68900;
}

.button-delete {
    background-color: #ff4d4d;
    color: white;
}

.button-delete:hover {
    background-color: #e60000;
}
</style>
