<style>
  /* Basic styling for the dashboard container */
.sm-dashboard-container {
    display: flex;
    flex-direction: row;
    max-width: 100vw;
}

/* Sidebar styling */


.sm-sidebar-nav ul {
    list-style: none;
    padding-left: 0;
}

.sm-sidebar-nav ul li {
    margin-bottom: 15px;
}

.sm-sidebar-nav ul li a {
    color: white;
    text-decoration: none;
    font-size: 18px;
}

.sm-sidebar-nav ul li a:hover {
    color: #ffcc00;
}

/* Main content styling */
.sm-main-content {
    flex: 1;
    background-color: #f9f9f9;
    padding: 20px;
}

/* Top Bar styling */
.sm-top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
}

.sm-user-info {
    font-size: 18px;
}

.sm-profile-link {
    color: white;
    text-decoration: none;
    margin-left: 10px;
}

.sm-profile-link:hover {
    text-decoration: underline;
}

.sm-notifications {
    position: relative;
}

.sm-notification-icon {
    font-size: 24px;
}

.sm-notification-count {
    position: absolute;
    top: 0;
    right: 0;
    background-color: red;
    color: white;
    border-radius: 50%;
    padding: 5px;
    font-size: 14px;
}

/* Dashboard Overview styling */
.sm-dashboard-overview {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
}

.sm-overview-card {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
    width: 30%;
}

.sm-overview-card h3 {
    font-size: 24px;
    margin-bottom: 10px;
}

.sm-overview-card p {
    font-size: 20px;
    color: #4CAF50;
}

</style>
    <div class="sm-dashboard-container">
       

        <!-- Main Content -->
        <main class="sm-main-content">
            <!-- Top Bar -->
            <header class="sm-top-bar">
                <div class="sm-user-info">
                    <span>Welcome, Admin</span>
                    <a href="#" class="sm-profile-link">Profile</a>
                </div>
                <div class="sm-notifications">
                    <a href="#" class="sm-notification-icon">🔔</a>
                    <span class="sm-notification-count">5</span>
                </div>
            </header>

            <!-- Dashboard Overview -->
            <section class="sm-dashboard-overview">
                <div class="sm-overview-card">
                    <h3>Students</h3>
                    <p>1,234 Students</p>
                </div>
                <div class="sm-overview-card">
                    <h3>Teachers</h3>
                    <p>75 Teachers</p>
                </div>
                <div class="sm-overview-card">
                    <h3>Attendance</h3>
                    <p>98% Attendance</p>
                </div>
            </section>
        </main>
    </div>
  
    
    
  

    
