<?php
global $wpdb;
$table_name = $wpdb->prefix . 'teachers';

// Fetch teacher to edit
$teacher_to_edit = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $teacher_to_edit = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $edit_id));
}

// Handle form submission to update teacher details
if (isset($_POST['update_teacher']) && check_admin_referer('update_teacher_action', 'update_teacher_nonce')) {
    $name = sanitize_text_field($_POST['name']);
    $father_name = sanitize_text_field($_POST['father_name']);
    $phone_number = sanitize_text_field($_POST['phone_number']);
    $email = sanitize_email($_POST['email']);
    $permanent_address = sanitize_text_field($_POST['permanent_address']);
    $teacher_id = intval($_POST['teacher_id']);
    $picture = $teacher_to_edit->teacher_picture;

    if (!empty($_FILES['teacher_picture']['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        $upload = wp_handle_upload($_FILES['teacher_picture'], ['test_form' => false]);
        if (!isset($upload['error'])) {
            $picture = esc_url_raw($upload['url']);
        }
    }

    $wpdb->update($table_name, [
        'name' => $name,
        'father_name' => $father_name,
        'phone_number' => $phone_number,
        'email' => $email,
        'permanent_address' => $permanent_address,
        'teacher_picture' => $picture,
    ], ['id' => $teacher_id]);

    echo '<div class="updated-message">Teacher updated successfully!</div>';
}

// Handle form submission to add a new teacher
if (isset($_POST['add_teacher']) && check_admin_referer('add_teacher_action', 'add_teacher_nonce')) {
    $name = sanitize_text_field($_POST['name']);
    $father_name = sanitize_text_field($_POST['father_name']);
    $phone_number = sanitize_text_field($_POST['phone_number']);
    $email = sanitize_email($_POST['email']);
    $permanent_address = sanitize_text_field($_POST['permanent_address']);
    $picture = '';

    if (!empty($_FILES['teacher_picture']['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        $upload = wp_handle_upload($_FILES['teacher_picture'], ['test_form' => false]);
        if (!isset($upload['error'])) {
            $picture = esc_url_raw($upload['url']);
        }
    }

    // Insert teacher data into custom table
    $wpdb->insert($table_name, [
        'name' => $name,
        'father_name' => $father_name,
        'phone_number' => $phone_number,
        'email' => $email,
        'permanent_address' => $permanent_address,
        'teacher_picture' => $picture,
    ]);

    // Create WordPress user for teacher
    $userdata = [
        'user_login' => $email,
        'user_email' => $email,
        'first_name' => $name,
        'last_name' => $father_name,
        'role' => 'teacher',
        'user_pass' => wp_generate_password(),
    ];
    wp_insert_user($userdata);
}

// Handle deletion of a teacher
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $wpdb->delete($table_name, ['id' => $delete_id]);
    echo '<div class="updated-message">Teacher deleted successfully!</div>';
}

// Fetch all teachers for display
$teachers = $wpdb->get_results("SELECT * FROM $table_name");
?>

<h2 class="page-title">Manage Teachers</h2>

<!-- Form to Add or Edit Teacher -->
<?php if (isset($teacher_to_edit)): ?>
    <!-- Edit Teacher Form -->
    <form method="post" enctype="multipart/form-data" class="teacher-form">
        <?php wp_nonce_field('update_teacher_action', 'update_teacher_nonce'); ?>
        <input type="hidden" name="teacher_id" value="<?php echo esc_attr($teacher_to_edit->id); ?>">

        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" value="<?php echo esc_attr($teacher_to_edit->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="father_name">Father's Name:</label>
            <input type="text" name="father_name" value="<?php echo esc_attr($teacher_to_edit->father_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="phone_number">Phone Number:</label>
            <input type="text" name="phone_number" value="<?php echo esc_attr($teacher_to_edit->phone_number); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo esc_attr($teacher_to_edit->email); ?>" required>
        </div>
        <div class="form-group">
            <label for="permanent_address">Permanent Address:</label>
            <input type="text" name="permanent_address" value="<?php echo esc_attr($teacher_to_edit->permanent_address); ?>" required>
        </div>
        <div class="form-group">
            <label for="teacher_picture">Picture:</label>
            <input type="file" name="teacher_picture" accept="image/*" onchange="previewImage(event)">
            <img id="picture-preview" src="<?php echo esc_url($teacher_to_edit->teacher_picture); ?>" style="max-width: 200px; display: block;">
        </div>

        <input type="submit" name="update_teacher" value="Update Teacher" class="button-primary">
    </form>
<?php else: ?>
    <!-- Add New Teacher Form -->
    <form method="post" enctype="multipart/form-data" class="teacher-form">
        <?php wp_nonce_field('add_teacher_action', 'add_teacher_nonce'); ?>

        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" required>
        </div>
        <div class="form-group">
            <label for="father_name">Father's Name:</label>
            <input type="text" name="father_name" required>
        </div>
        <div class="form-group">
            <label for="phone_number">Phone Number:</label>
            <input type="text" name="phone_number" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="permanent_address">Permanent Address:</label>
            <input type="text" name="permanent_address" required>
        </div>
        <div class="form-group">
            <label for="teacher_picture">Picture:</label>
            <input type="file" name="teacher_picture" accept="image/*" onchange="previewImage(event)">
            <img id="picture-preview" style="max-width: 200px; display: none;">
        </div>

        <input type="submit" name="add_teacher" value="Add Teacher" class="button-primary">
    </form>
<?php endif; ?>

<!-- Table to Display All Teachers -->
<table class="teachers-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Father's Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Permanent Address</th>
            <th>Picture</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($teachers as $teacher): ?>
            <tr>
                <td><?php echo esc_html($teacher->name); ?></td>
                <td><?php echo esc_html($teacher->father_name); ?></td>
                <td><?php echo esc_html($teacher->phone_number); ?></td>
                <td><?php echo esc_html($teacher->email); ?></td>
                <td><?php echo esc_html($teacher->permanent_address); ?></td>
                <td><img src="<?php echo esc_url($teacher->teacher_picture); ?>" alt="Teacher Picture" width="100"></td>
                <td>
                    <a href="?page=teacher-management&edit_id=<?php echo esc_attr($teacher->id); ?>">Edit</a> | 
                    <a href="?page=teacher-management&delete_id=<?php echo esc_attr($teacher->id); ?>" onclick="return confirm('Are you sure?');">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script>
    // Image preview function
    function previewImage(event) {
        const preview = document.getElementById('picture-preview');
        const reader = new FileReader();

        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }

        reader.readAsDataURL(event.target.files[0]);
    }
</script>
<style>
    /* General styles for the page */
    .page-title {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 20px;
    }

    /* Form styling */
    .teacher-form {
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .form-group input[type="text"],
    .form-group input[type="email"],
    .form-group input[type="file"] {
        width: 100%;
        padding: 8px;
        border-radius: 4px;
        border: 1px solid #ccc;
    }

    .teacher-form input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 4px;
    }

    .teacher-form input[type="submit"]:hover {
        background-color: #45a049;
    }

    /* Table styling */
    .teachers-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .teachers-table th, .teachers-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .teachers-table th {
        background-color: #4CAF50;
        color: white;
    }

    .teachers-table tr:hover {
        background-color: #f1f1f1;
    }

    .teacher-picture {
        max-width: 100px;
        max-height: 100px;
        object-fit: cover;
    }

    /* Message styles */
    .updated-message {
        background-color: #d4edda;
        color: #155724;
        padding: 10px;
        border-radius: 4px;
        margin-top: 20px;
    }

    .error-message {
        background-color: #f8d7da;
        color: #721c24;
        padding: 10px;
        border-radius: 4px;
        margin-top: 20px;
    }

    /* Image preview styling */
    #picture-preview {
        margin-top: 10px;
        max-width: 200px;
        max-height: 200px;
        object-fit: cover;
        display: none;
    }
</style>
