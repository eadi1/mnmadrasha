=== MN MADRASHA ===
Contributors: eadi
Tags: school management, madrasa, education, student management, teacher management, attendance, grades, subjects
Requires at least: 5.6
Tested up to: 6.7
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The MN MADRASA plugin is a powerful and intuitive school management solution tailored specifically for madrassas and educational institutions. This plugin simplifies administrative tasks by offering features for managing student records, teacher profiles, class schedules, attendance tracking, grades, and subject assignments. With its user-friendly interface and customizable features, MN MADRASA ensures streamlined management for both educators and administrators, allowing them to focus on delivering quality education and fostering student success.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/mn-madrasa/` directory, or install the plugin through the WordPress plugin screen directly.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. After activation, you can start using the plugin by navigating to the MN MADRASA menu in your WordPress admin dashboard.

== Frequently Asked Questions ==

= What features does MN MADRASA offer? =
MN MADRASA includes functionalities for managing student records, teacher profiles, attendance tracking, grades, subjects, and class assignments. It also allows you to manage student requests, payment history, and publish results.

= Can I customize the plugin for my institution's needs? =
Yes, the MN MADRASA plugin is designed to be flexible and customizable. You can easily add, edit, or remove features to match your institution's unique requirements.

= How can I get support for the plugin? =
For support, please visit our support forum or contact us directly at [eadimahabub87@gmail.com].

== Changelog ==

= 1.1 =
* Initial release with features for managing students, teachers,  and subjects.

= 1.0 =
* Alpha release with basic school management functionality.

== Screenshots ==

1. Screenshot of the MN MADRASA Dashboard.
   Screenshot: /wp-content/plugins/mn-madrasa/screenshot5.jpg
2. Screenshot of the MN MADRASA Class Management.
   Screenshot: /wp-content/plugins/mn-madrasa/screenshot1.jpg
3. Screenshot of the MN MADRASA Subjects Management.
   Screenshot: /wp-content/plugins/mn-madrasa/screenshot2.jpg
4. Screenshot of the MN MADRASA Teacher Management.
   Screenshot: /wp-content/plugins/mn-madrasa/screenshot3.jpg

5. Screenshot of the MN MADRASA Class wise Subject Management.
   Screenshot: /wp-content/plugins/mn-madrasa/screenshot4.jpg

== Banner Image ==

Banner: /wp-content/plugins/mn-madrasa/banner.webp
