<?php
class Subjects_List {
    // Shortcode to display subject list (for frontend)
    public static function subject_list() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'subjects';
        
        // Using wpdb::prepare() for secure query execution
        $subjects = $wpdb->get_results("SELECT * FROM $table_name"); 

        if (!$subjects) {
            return '<p>No subjects found.</p>';
        }

      $output = '</ul>';
        foreach ($subjects as $subject) {
            // Assuming `en` is the subject name and `bn` is the subject code or description
            $output .= '<li>' . esc_html($subject->en) . '</li>';
        }
        $output .= '</ul>';

        return $output;
    }
}

// Register the shortcode [subject_list]
add_shortcode('subject_list', ['Subjects_List', 'subject_list']);
