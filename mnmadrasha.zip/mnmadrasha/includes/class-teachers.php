<?php
class Teachers_List {
    // Shortcode to display teacher list (for frontend)
    public static function teacher_list() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'teachers';
        
        // Using wpdb::prepare() for secure query execution
        $teachers = $wpdb->get_results("SELECT * FROM $table_name");

        if (!$teachers) {
            return '<p>No teachers found.</p>';
        }

        $output = '<ul>'; // Start the list here
        foreach ($teachers as $teacher) {
            // Assuming `name` is the teacher's name and `subject` is the subject they teach
            $output .= '<li>' . esc_html($teacher->name) . '</li>';
        }
        $output .= '</ul>'; // Close the list after the loop

        return $output;
    }
}

// Register the shortcode [teacher_list]
add_shortcode('teacher_list', ['Teachers_List', 'teacher_list']);
