<?php
class Classes {
    // Shortcode to display class list (for frontend, if needed)
    public static function class_list() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'classes';
        
        // Using wpdb::prepare() for secure query execution
        $query = $wpdb->prepare("SELECT * FROM $table_name", []);
        $classes = $wpdb->get_results($query);

        $output = '<h2>Class List</h2><ul>';
        foreach ($classes as $class) {
            $output .= '<li>' . esc_html($class->en) . ' - Section: ' . esc_html($class->bn) . '</li>';
        }
        $output .= '</ul>';

        return $output;
    }

    // Add, edit, and delete classes (for admin page)
    
}
add_shortcode('class_list', ['Classes', 'class_list']);
