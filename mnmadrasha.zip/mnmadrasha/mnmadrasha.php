<?php
/*
Plugin Name:MN MADRASHA
Description: The MN MADRASA plugin is a powerful and intuitive school management solution tailored specifically for madrassas and educational institutions. This plugin simplifies administrative tasks by offering features for managing student records, teacher profiles, class schedules, attendance tracking, grades, and subject assignments. With its user-friendly interface and customizable features, MN MADRASA ensures streamlined management for both educators and administrators, allowing them to focus on delivering quality education and fostering student success.
Version: 1.0
Author: eadi
Author URI: https://github.com/eadi1
Plugin URI: https://wordpress.org/plugins/mn-madrasha
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: mn-madrasha
*/

defined('ABSPATH') or die('No script kiddies please!');


// Include necessary files

include(plugin_dir_path(__FILE__) . 'includes/class-teachers.php');
include(plugin_dir_path(__FILE__) . 'includes/class-subjects.php');
include(plugin_dir_path(__FILE__) . 'includes/class-classes.php');

// Register custom database tables on plugin activation


// Callback functions

include(plugin_dir_path(__FILE__) . 'function.php');



register_activation_hook(__FILE__, 'school_management_plugin_activate');
register_deactivation_hook(__FILE__, 'school_management_plugin_deactivate');

// Display Resul
function mnmadrasha_enqueue_styles() {
    wp_enqueue_style('mnmadrasha-style', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('wp_enqueue_scripts', 'mnmadrasha_enqueue_styles');

